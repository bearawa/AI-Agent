import sqlite3
import datetime
import uuid
from typing import List, Dict, Any, Optional
from config import settings
from utils.logger import logger

def get_connection():
    """
    获取 SQLite 连接。
    """
    conn = sqlite3.connect(settings.SQLITE_PATH)
    conn.row_factory = sqlite3.Row  # 返回字典格式的数据
    return conn

def init_db():
    """
    初始化 SQLite 数据库及建表。
    """
    logger.info("正在初始化 SQLite 数据库...")
    with get_connection() as conn:
        cursor = conn.cursor()
        
        # 1. documents 表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS documents (
                doc_id TEXT PRIMARY KEY,
                file_name TEXT NOT NULL,
                file_path TEXT NOT NULL,
                file_type TEXT NOT NULL,
                file_hash TEXT UNIQUE NOT NULL,
                uploaded_at TEXT NOT NULL,
                status TEXT NOT NULL,
                chunk_count INTEGER DEFAULT 0,
                error_message TEXT
            )
        ''')

        # 2. chat_sessions 表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chat_sessions (
                session_id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        ''')

        # 3. messages 表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                message_id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES chat_sessions(session_id) ON DELETE CASCADE
            )
        ''')

        # 4. message_sources 表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS message_sources (
                source_id TEXT PRIMARY KEY,
                message_id TEXT NOT NULL,
                doc_id TEXT NOT NULL,
                chunk_id TEXT NOT NULL,
                file_name TEXT NOT NULL,
                page_number INTEGER,
                chunk_index INTEGER NOT NULL,
                source_text TEXT NOT NULL,
                similarity_distance REAL NOT NULL,
                FOREIGN KEY (message_id) REFERENCES messages(message_id) ON DELETE CASCADE
            )
        ''')
        
        conn.commit()
    logger.info("SQLite 数据库初始化完成")

# --- Documents 相关操作 ---

def save_document(doc_id: str, file_name: str, file_path: str, file_type: str, file_hash: str, status: str = "processing") -> bool:
    """
    保存或初始化一个文档记录。
    """
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO documents (doc_id, file_name, file_path, file_type, file_hash, uploaded_at, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (doc_id, file_name, file_path, file_type, file_hash, now, status))
            conn.commit()
        return True
    except sqlite3.Error as e:
        logger.error(f"保存文档记录到数据库失败: {e}")
        return False

def update_document_status(doc_id: str, status: str, chunk_count: int = 0, error_message: str = None) -> bool:
    """
    更新文档状态和切片数量。
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE documents
                SET status = ?, chunk_count = ?, error_message = ?
                WHERE doc_id = ?
            ''', (status, chunk_count, error_message, doc_id))
            conn.commit()
        return True
    except sqlite3.Error as e:
        logger.error(f"更新文档状态失败: {e}")
        return False

def get_document_by_hash(file_hash: str) -> Optional[Dict[str, Any]]:
    """
    根据文件内容哈希查找文档。
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM documents WHERE file_hash = ?', (file_hash,))
            row = cursor.fetchone()
            return dict(row) if row else None
    except sqlite3.Error as e:
        logger.error(f"通过哈希查询文档失败: {e}")
        return None

def list_documents() -> List[Dict[str, Any]]:
    """
    列出所有文档。
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM documents ORDER BY uploaded_at DESC')
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
    except sqlite3.Error as e:
        logger.error(f"查询文档列表失败: {e}")
        return []

def delete_document_record(doc_id: str) -> bool:
    """
    删除文档记录。用于导入失败时清理数据。
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM documents WHERE doc_id = ?', (doc_id,))
            conn.commit()
        return True
    except sqlite3.Error as e:
        logger.error(f"删除文档记录失败: {e}")
        return False


# --- Chat Sessions 相关操作 ---

def create_chat_session(title: str, session_id: str = None) -> str:
    """
    创建一个新的会话。若未提供 session_id，则自动生成 UUID。
    返回 session_id。
    """
    if not session_id:
        session_id = str(uuid.uuid4())
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO chat_sessions (session_id, title, created_at, updated_at)
                VALUES (?, ?, ?, ?)
            ''', (session_id, title, now, now))
            conn.commit()
        logger.info(f"成功创建会话: {session_id}, 标题: {title}")
        return session_id
    except sqlite3.Error as e:
        logger.error(f"创建会话失败: {e}")
        raise e

def update_session_title(session_id: str, title: str) -> bool:
    """
    更新会话标题。
    """
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE chat_sessions
                SET title = ?, updated_at = ?
                WHERE session_id = ?
            ''', (title, now, session_id))
            conn.commit()
        return True
    except sqlite3.Error as e:
        logger.error(f"更新会话标题失败: {e}")
        return False

def list_chat_sessions() -> List[Dict[str, Any]]:
    """
    列出所有会话，按最后更新时间倒序。
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            # 顺便统计每个会话的消息数量
            cursor.execute('''
                SELECT s.session_id, s.title, s.created_at, s.updated_at, COUNT(m.message_id) as message_count
                FROM chat_sessions s
                LEFT JOIN messages m ON s.session_id = m.session_id
                GROUP BY s.session_id
                ORDER BY s.updated_at DESC
            ''')
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
    except sqlite3.Error as e:
        logger.error(f"查询会话列表失败: {e}")
        return []

def delete_chat_session(session_id: str) -> bool:
    """
    级联删除会话及其对应的消息和引用来源。
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            # 开启外键约束支持以实现级联删除
            cursor.execute("PRAGMA foreign_keys = ON")
            cursor.execute('DELETE FROM chat_sessions WHERE session_id = ?', (session_id,))
            conn.commit()
        logger.info(f"成功级联删除会话: {session_id}")
        return True
    except sqlite3.Error as e:
        logger.error(f"级联删除会话失败: {e}")
        return False


# --- Messages 相关操作 ---

def save_message(session_id: str, role: str, content: str, message_id: str = None) -> str:
    """
    保存一条对话消息。返回 message_id。
    并在写入消息后，自动更新会话的 updated_at。
    """
    if not message_id:
        message_id = str(uuid.uuid4())
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            # 保存消息
            cursor.execute('''
                INSERT INTO messages (message_id, session_id, role, content, created_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (message_id, session_id, role, content, now))
            
            # 更新会话的最后更新时间
            cursor.execute('''
                UPDATE chat_sessions
                SET updated_at = ?
                WHERE session_id = ?
            ''', (now, session_id))
            
            conn.commit()
        return message_id
    except sqlite3.Error as e:
        logger.error(f"保存消息失败: {e}")
        raise e

def get_chat_messages(session_id: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    """
    获取某会话的历史消息。
    :param limit: 限制获取消息的数量。如果设置，会获取最新 limit 条（但需要按时间正序排列返回）。
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            if limit:
                # 获取最新的 limit 条消息（排在后面的物理写入顺序最新的消息）
                cursor.execute('''
                    SELECT * FROM (
                        SELECT *, rowid FROM messages 
                        WHERE session_id = ? 
                        ORDER BY rowid DESC 
                        LIMIT ?
                    ) ORDER BY rowid ASC
                ''', (session_id, limit))
            else:
                cursor.execute('''
                    SELECT *, rowid FROM messages 
                    WHERE session_id = ? 
                    ORDER BY rowid ASC
                ''', (session_id,))
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
    except sqlite3.Error as e:
        logger.error(f"查询历史消息失败: {e}")
        return []


# --- Message Sources 相关操作 ---

def save_message_sources(message_id: str, sources: List[Dict[str, Any]]) -> bool:
    """
    保存助手回答的原文来源列表。
    sources 列表项应包含: doc_id, chunk_id, file_name, page_number, chunk_index, source_text, similarity_distance
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            for src in sources:
                source_id = str(uuid.uuid4())
                cursor.execute('''
                    INSERT INTO message_sources (
                        source_id, message_id, doc_id, chunk_id, file_name, page_number, chunk_index, source_text, similarity_distance
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    source_id,
                    message_id,
                    src['doc_id'],
                    src['chunk_id'],
                    src['file_name'],
                    src.get('page_number'),
                    src['chunk_index'],
                    src['source_text'],
                    src['similarity_distance']
                ))
            conn.commit()
        return True
    except sqlite3.Error as e:
        logger.error(f"保存消息来源失败: {e}")
        return False

def get_message_sources(message_id: str) -> List[Dict[str, Any]]:
    """
    获取某条消息的所有原文引用来源。
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM message_sources 
                WHERE message_id = ?
                ORDER BY similarity_distance ASC
            ''', (message_id,))
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
    except sqlite3.Error as e:
        logger.error(f"查询消息来源失败: {e}")
        return []
