from typing import List
from openai import OpenAI
from config import settings
from utils.logger import logger

class EmbeddingService:
    def __init__(self):
        """
        初始化 Embedding 服务。
        """
        self.api_key = settings.DASHSCOPE_API_KEY
        self.base_url = settings.DASHSCOPE_BASE_URL
        self.model = settings.EMBEDDING_MODEL
        
        # 延迟校验，只有在需要调用时才抛错，防止服务启动时直接崩溃
        self._client = None

    @property
    def client(self) -> OpenAI:
        if not self.api_key:
            raise ValueError("未检测到 API 密钥（DASHSCOPE_API_KEY 为空），请在 .env 文件中配置后再试。")
        if self._client is None:
            self._client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
        return self._client

    def get_embedding(self, text: str) -> List[float]:
        """
        为单条文本生成向量。
        """
        if not text or not text.strip():
            raise ValueError("输入文本不能为空")

        try:
            logger.debug(f"正在为文本生成向量 (模型: {self.model}): {text[:20]}...")
            response = self.client.embeddings.create(
                model=self.model,
                input=text
            )
            embedding = response.data[0].embedding
            return embedding
        except Exception as e:
            logger.error(f"调用 Embedding 接口生成向量失败: {e}")
            raise RuntimeError(f"Embedding 服务调用失败: {str(e)}")

    def get_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """
        批量为文本列表生成向量。
        """
        if not texts:
            return []
        
        # 过滤可能存在的空字符串
        valid_texts = [t if t.strip() else " " for t in texts]

        try:
            logger.info(f"正在批量生成 {len(valid_texts)} 条文本的向量...")
            response = self.client.embeddings.create(
                model=self.model,
                input=valid_texts
            )
            # 保持输入顺序返回向量列表
            embeddings = [item.embedding for item in response.data]
            logger.info("批量生成向量成功")
            return embeddings
        except Exception as e:
            logger.error(f"批量调用 Embedding 接口生成向量失败: {e}")
            raise RuntimeError(f"批量 Embedding 服务调用失败: {str(e)}")
