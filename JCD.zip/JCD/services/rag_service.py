import os
import uuid
from typing import List, Dict, Any, Optional
from config import settings
from utils.logger import logger
from utils.file_utils import calculate_file_hash, save_uploaded_file
from repositories import sqlite_repository
from repositories.chroma_repository import ChromaRepository
from services.embedding_service import EmbeddingService
from services.document_service import DocumentService

class RAGService:
    def __init__(self):
        """
        初始化 RAG 服务，协调文档解析、Embedding、向量数据库和关系数据库。
        """
        self.chroma_repo = ChromaRepository()
        self.embedding_service = EmbeddingService()
        self.doc_service = DocumentService(
            chunk_size=500,  # 约 400~600 字符
            chunk_overlap=100  # 重叠约 80~120 字符
        )

    def import_document(self, file_name: str, file_bytes: bytes) -> str:
        """
        导入上传的文件到 RAG 系统中（解析 -> 向量化 -> 入向量库 -> 入关系库）。
        :param file_name: 原始文件名
        :param file_bytes: 文件二进制内容
        :return: 返回生成的 doc_id
        """
        # 1. 计算文件哈希值并去重校验
        file_hash = calculate_file_hash(file_bytes)
        existing_doc = sqlite_repository.get_document_by_hash(file_hash)
        if existing_doc:
            logger.warning(f"检测到重复文件上传，文件名: {file_name}, 已存在 ID: {existing_doc['doc_id']}")
            raise ValueError(f"该文件已在知识库中导入（文件名：{existing_doc['file_name']}），请勿重复上传。")

        # 2. 生成文档 ID 并保存到本地
        doc_id = str(uuid.uuid4())
        _, ext = os.path.splitext(file_name)
        file_type = ext.lower().lstrip('.')
        
        # 存到 raw_documents
        local_path = save_uploaded_file(file_name, file_bytes)

        # 3. 在 SQLite 中记录初始状态 (processing)
        success = sqlite_repository.save_document(
            doc_id=doc_id,
            file_name=file_name,
            file_path=local_path,
            file_type=file_type,
            file_hash=file_hash,
            status="processing"
        )
        if not success:
            # 若记录 SQLite 失败，清理已保存的文件，并抛错
            if os.path.exists(local_path):
                os.remove(local_path)
            raise RuntimeError("在 SQLite 中记录文档信息失败")

        # 4. 解析、切片并向量化导入
        try:
            # 解析文档
            parsed_chunks = self.doc_service.parse_document(local_path, file_type)
            if not parsed_chunks:
                raise ValueError("该文档解析出的文本切片数量为 0")

            # 提取切片原文及组装元数据
            chunk_texts = [item["text"] for item in parsed_chunks]
            metadatas = [
                {
                    "page_number": item["page_number"] if item["page_number"] is not None else -1,
                    "chunk_index": item["chunk_index"]
                }
                for item in parsed_chunks
            ]

            # 批量获取 Embeddings 向量
            embeddings = self.embedding_service.get_embeddings_batch(chunk_texts)

            # 写入本地向量库
            self.chroma_repo.add_chunks(
                doc_id=doc_id,
                file_name=file_name,
                file_type=file_type,
                chunks=chunk_texts,
                embeddings=embeddings,
                metadatas=metadatas
            )

            # 更新 SQLite 记录为 completed 状态
            sqlite_repository.update_document_status(
                doc_id=doc_id,
                status="completed",
                chunk_count=len(parsed_chunks)
            )
            logger.info(f"文档 {file_name} 导入并向量化成功！")
            return doc_id

        except Exception as e:
            # 捕获异常后触发清理机制
            logger.error(f"导入文档 {file_name} 失败，开始清理残留数据: {e}")
            
            # 清理 Chroma 向量库
            self.chroma_repo.delete_by_doc_id(doc_id)
            
            # 更新 SQLite 记录为 failed 状态
            error_msg = str(e)
            sqlite_repository.update_document_status(
                doc_id=doc_id,
                status="failed",
                chunk_count=0,
                error_message=error_msg
            )
            raise RuntimeError(f"文档导入失败: {error_msg}")

    def search_relevant_chunks(self, query_text: str, top_k: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        根据用户问题（改写后的检索问题）在向量数据库中检索最相似的切片。
        并应用相关性阈值过滤 (distance <= settings.RAG_DISTANCE_THRESHOLD)。
        """
        if not top_k:
            top_k = settings.RAG_TOP_K

        logger.info(f"正在检索相关文档切片，检索词: '{query_text}'，Top K: {top_k}")
        
        try:
            # 对检索词进行向量化
            query_embedding = self.embedding_service.get_embedding(query_text)
            
            # 检索相似文本
            results = self.chroma_repo.query_similar_chunks(query_embedding, top_k=top_k)
            
            # 过滤距离在阈值内的结果
            filtered_results = []
            for item in results:
                dist = item["similarity_distance"]
                # 距离越小越接近，余弦距离通常为 1-cosine_similarity，所以要小于阈值
                if dist <= settings.RAG_DISTANCE_THRESHOLD:
                    filtered_results.append(item)
                else:
                    logger.debug(f"切片被过滤: 相似度距离 {dist:.4f} 超过阈值 {settings.RAG_DISTANCE_THRESHOLD}")

            logger.info(f"检索完成。符合距离阈值过滤条件的切片有 {len(filtered_results)}/{len(results)} 个")
            return filtered_results
        except Exception as e:
            logger.error(f"执行 RAG 检索发生异常: {e}")
            # 如果是 API Key 没配置，这里的抛错可以在前端被拦截
            raise e
