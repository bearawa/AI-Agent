from typing import List, Dict, Any, Generator
from config import settings
from utils.logger import logger
from repositories import sqlite_repository
from services.llm_service import LLMService
from services.rag_service import RAGService

class ChatService:
    def __init__(self):
        """
        初始化对话服务。
        """
        self.llm_service = LLMService()
        self.rag_service = RAGService()

    def start_new_session(self, title: str = "新建会话") -> str:
        """
        创建并返回一个新会话的 ID。
        """
        return sqlite_repository.create_chat_session(title)

    def handle_chat_flow(
        self,
        session_id: str,
        user_content: str
    ) -> Generator[Dict[str, Any], None, None]:
        """
        核心 RAG 聊天问答流，整合历史获取、检索改写、向量匹配和流式生成。
        由于 Streamlit 需要拿到检索出的来源并在流式生成前/后进行展示，我们通过 Generator 返回：
        - 首先 yield 一个特殊的 "metadata" 字典，包含检索到的 sources 列表。
        - 接着 yield 字符串（即流式文本块）。
        - 流式完全结束后，内部自动保存消息和引用源到 SQLite。
        """
        # 1. 保存用户的提问到关系库
        user_msg_id = sqlite_repository.save_message(session_id, role="user", content=user_content)
        
        # 2. 如果当前会话标题是默认值，尝试以用户首个问题的前15个字更新会话标题
        history_msgs = sqlite_repository.get_chat_messages(session_id)
        # 排除刚才插入的那条，看是否有其它消息。若刚才插入的是第一条消息，则更新标题
        user_msgs_only = [m for m in history_msgs if m["role"] == "user"]
        if len(user_msgs_only) == 1:
            new_title = user_content.strip()[:15]
            if len(user_content) > 15:
                new_title += "..."
            sqlite_repository.update_session_title(session_id, new_title)
            logger.info(f"会话 {session_id} 接收到首条消息，标题已更新为: '{new_title}'")

        # 3. 读取最近的 6 条（即 3 轮对话）历史消息，用于改写检索词
        # settings.MAX_HISTORY_MESSAGES 默认是 6。
        # 我们获取最近的 MAX_HISTORY_MESSAGES 条记录，但不包括刚刚插入的这一条用户问题
        recent_history = sqlite_repository.get_chat_messages(session_id, limit=settings.MAX_HISTORY_MESSAGES + 1)
        recent_history = [m for m in recent_history if m["message_id"] != user_msg_id]
        
        # 将 SQLite 的行转换为 LLMService 需要的格式：{"role": ..., "content": ...}
        formatted_history = [
            {"role": m["role"], "content": m["content"]}
            for m in recent_history
        ]

        # 4. 对问题进行改写
        rewritten_query = self.llm_service.rewrite_query(formatted_history, user_content)

        # 5. 检索知识库
        try:
            retrieved_chunks = self.rag_service.search_relevant_chunks(rewritten_query)
        except Exception as e:
            logger.error(f"检索向量库失败: {e}")
            retrieved_chunks = []
            # 我们不中断，可以继续尝试用 LLM 直接问答，或后续流中抛错

        # 6. 首先向前端返回检索源数据，用特殊格式包装，便于前端区分
        yield {"type": "sources", "data": retrieved_chunks}

        # 7. 流式回答
        full_response = ""
        try:
            response_generator = self.llm_service.chat_stream(
                history=formatted_history,
                retrieved_chunks=retrieved_chunks,
                current_query=user_content
            )
            for text_chunk in response_generator:
                full_response += text_chunk
                yield {"type": "text", "data": text_chunk}
        except Exception as e:
            logger.error(f"流式获取助手回答失败: {e}")
            yield {"type": "error", "data": f"获取回答时发生异常: {str(e)}"}
            return

        # 8. 回答流生成完毕，将完整回答存入关系数据库
        if full_response.strip():
            assistant_msg_id = sqlite_repository.save_message(
                session_id=session_id,
                role="assistant",
                content=full_response
            )
            
            # 9. 将检索到的切片（作为本次回答的来源）存入 SQLite 来源表
            if retrieved_chunks:
                sources_to_save = []
                for chunk in retrieved_chunks:
                    sources_to_save.append({
                        "doc_id": chunk["doc_id"],
                        "chunk_id": chunk["chunk_id"],
                        "file_name": chunk["file_name"],
                        "page_number": chunk["page_number"],
                        "chunk_index": chunk["chunk_index"],
                        "source_text": chunk["source_text"],
                        "similarity_distance": chunk["similarity_distance"]
                    })
                sqlite_repository.save_message_sources(assistant_msg_id, sources_to_save)
                logger.info(f"已成功在 SQLite 中保存消息 {assistant_msg_id} 的 {len(sources_to_save)} 个原文来源记录")
