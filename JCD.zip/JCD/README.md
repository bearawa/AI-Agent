# AI智能客服平台（校园版）基础档 MVP

本项目是一个面向学生与家长的校园智能咨询系统基础档 MVP，基于 **Python 3.11+**、**Streamlit**、**ChromaDB**、**SQLite** 以及阿里云百炼 **qwen-plus** 与 **text-embedding-v3** 构建。系统采用纯中文交互，支持文档解析导入、语义向量化、本地双数据库存储、多轮检索改写问答、流式回答及会话历史管理。

---

## 🏫 功能范围

1. **多格式文档解析**：支持 `.pdf`、`.docx`、`.txt` 格式的校园政策、规章制度文件解析与中文语义切分。
2. **页码/片段自适应溯源**：针对 PDF 解析保留物理页码信息；针对 Word/TXT 解析生成片段编号，拒绝编造来源。
3. **RAG 向量检索与阈值过滤**：使用本地 ChromaDB 持久化集合，计算检索余弦距离，只将符合阈值条件的段落作为上下文。
4. **多轮改写问答**：自动读取会话最近 6 条消息（3 轮对话），使用 `qwen-plus` 自动重写当前追问，消除代词与上下文依赖，使其成为语义完整的问题后再进行向量搜索。
5. **流式文字渲染与引用来源**：通过 OpenAI SDK 的 stream 兼容接口，流式返回助手的文字块，并在回答下方以折叠框格式展示出处（文件名、页码/片段编号、原文片段、匹配相似度度量）。
6. **历史会话存档**：用户可新建会话、切换不同会话查看历史记录，或随时删除冗余会话。

---

## 📁 目录结构

```text
ai-campus-customer-service/ (工作区根目录)
├─ app.py                     # Streamlit 入口跳转程序（兼顾表初始化）
├─ requirements.txt           # 项目第三方依赖清单
├─ .env.example               # 环境变量配置示例
├─ README.md                  # 中文使用说明书
├─ config/
│  └─ settings.py             # 统一配置与物理路径自动创建
├─ pages/
│  ├─ 1_校园咨询.py            # 多轮流式检索聊天核心页
│  ├─ 2_知识库导入.py          # 文档上传去重、解析导入监控页
│  └─ 3_对话历史.py            # 历史会话档案检索与重播页
├─ services/
│  ├─ llm_service.py          # qwen-plus 问题改写与流式生成封装
│  ├─ embedding_service.py    # text-embedding-v3 向量提取封装
│  ├─ document_service.py     # PDF/Word/TXT 文档智能解析器
│  ├─ rag_service.py          # RAG 切分向量化入库与过滤匹配流程
│  └─ chat_service.py         # 多轮会话流水线编排服务
├─ repositories/
│  ├─ sqlite_repository.py    # SQLite 表初始化及聊天记录、引用源存取
│  └─ chroma_repository.py    # ChromaDB 本地持久化及余弦匹配检索
├─ utils/
│  ├─ text_splitter.py        # 中文语义分句与重叠滑动切分器
│  ├─ file_utils.py           # 文件 SHA-256 哈希计算与上传保存工具
│  └─ logger.py               # 中文日志封装（输出到终端及 logs/app.log）
├─ tests/
│  ├─ test_sqlite_repository.py  # SQLite 增删改查及级联删除测试
│  ├─ test_document_service.py   # PDF页码/DOCX/TXT本地切分测试
│  └─ test_rag_service.py        # 导入事务回滚及距离过滤测试
└─ data/ (自动创建，被 gitignore)
   ├─ raw_documents/          # 上传文件物理保存目录
   ├─ chroma_db/              # 本地 ChromaDB 向量持久化目录
   └─ campus_service.db       # 本地 SQLite 关系数据库
```

---

## ⚙️ 环境配置

1. 在项目根目录下，将 `.env.example` 复制一份并重命名为 `.env`。
2. 打开 `.env`，填入您在阿里云百炼申请到的有效 **DASHSCOPE_API_KEY**：

```ini
# 阿里云百炼 API 密钥与基础配置
DASHSCOPE_API_KEY=您的_DASHSCOPE_API_KEY
DASHSCOPE_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1

# 模型配置
CHAT_MODEL=qwen-plus
EMBEDDING_MODEL=text-embedding-v3

# 存储路径
CHROMA_DIR=data/chroma_db
SQLITE_PATH=data/campus_service.db
UPLOAD_DIR=data/raw_documents

# RAG 与会话检索参数
RAG_TOP_K=5
RAG_DISTANCE_THRESHOLD=0.8
MAX_HISTORY_MESSAGES=6

# 日志级别
LOG_LEVEL=INFO
```

---

## 🚀 安装与启动步骤

### 1. 安装依赖包
确保安装了 Python 3.11+ 环境，然后在终端执行命令：
```bash
pip install -r requirements.txt
```

### 2. 运行自动化测试
可直接运行离线单元测试，验证各模块的正确性。测试不需要真实的 `.env` 密钥配置：
```bash
python -m unittest discover -s tests
```
预期输出：`Ran 9 tests in ...s` ➡️ `OK`。

### 3. 启动 Streamlit 客服平台
在终端根目录下运行：
```bash
streamlit run app.py
```
启动后，系统会自动在浏览器中弹出 `http://localhost:8501`。如果未弹出，可手动复制该地址并在浏览器中打开。

---

## 📖 如何导入文档

1. 浏览器打开平台后，点击左侧菜单栏切换到 **“知识库导入”** 页面。
2. 拖拽或上传一个文件（如 PDF 格式的手册，或包含某些具体问答的 `.txt` / `.docx`）。
3. 点击 **“开始解析并导入知识库”** 按钮。
4. 页面底部的列表将实时展示上传文件的类型、切片数量、导入时间以及其处理状态（处理成功显示为 `🟢 成功`）。
5. 再次上传完全相同的文件，系统会提示已在知识库中导入，防止冗余和哈希冲突。

---

## ✅ 如何验证基础档验收项

1. **防编造依据测试**：
   - 导入一份包含某些规则（例如：国家奖学金 8000 元/年）的文件。
   - 提问在文档中完全不存在的问题，例如：*“火星上的国家奖学金是多少钱？”*。
   - 客服助手应回答：*“当前知识库未检索到相关依据”*，这证明了系统不存在虚假知识幻觉。
2. **信息来源物理溯源测试**：
   - 提问导入文档中存在的问题，例如：*“国家奖学金能拿多少钱？”*。
   - 助手完成流式输出后，回答卡片下方应会显示折叠区 **“🔍 信息来源”**。
   - 展开折叠区，查看引用，如果是 PDF，应该能看到 *第 X 页*；如果是 DOCX/TXT，应该显示为 *片段 X*，并且匹配程度高度吻合，包含了原文片段。
3. **流式输出测试**：
   - 输入问题后，可以看到助手的字符像打字机一样逐字递增渲染，并带有光标特效。
4. **多轮对话与追问理解测试**：
   - 先提问：*“学校的奖学金有哪些？”*
   - 助手给出回答。
   - 继续追问：*“那它们的申请条件是什么？”* 
   - 助手应当正常理解“它们”是指上一轮学校的奖学金，并正确检索并作答。可以通过后台日志 `logs/app.log` 查看到类似于：*“改写后的检索提问: '学校奖学金的申请条件是什么'”* 的改写审计记录。
5. **对话历史还原测试**：
   - 页面左侧栏点击会话列表中的历史按钮进行来回切换，确认聊天历史及信息出处能完全渲染还原。
   - 在 **“对话历史”** 页面，选择归档，确认能展示完整的会话元数据（创建更新时间、消息数量等），并且能流畅回看聊天重播。
