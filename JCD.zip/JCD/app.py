import streamlit as st
from repositories import sqlite_repository
from utils.logger import logger

# 1. 启动时执行数据库表初始化，保证第一次运行应用时库表就绪
try:
    sqlite_repository.init_db()
except Exception as e:
    logger.error(f"应用启动初始化 SQLite 数据库失败: {e}")

# 2. 页面配置设定
st.set_page_config(
    page_title="AI智能客服平台（校园版）",
    page_icon="🏫",
    layout="wide"
)

# 3. 自动跳转到校园咨询主页面
st.switch_page("pages/1_校园咨询.py")
